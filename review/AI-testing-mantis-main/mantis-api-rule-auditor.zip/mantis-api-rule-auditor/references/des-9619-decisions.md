# DES-9619 decision log

Source: Jira issue DES-9619, its comments, and the repository's normalized rule
artifacts. Treat the issue's unanswered questions as open; do not infer a product
decision from the fact that a question was asked.

## Confirmed product decisions

- Sandbox is a fresh Mantis routing preview. Opening Sandbox runs against System,
  Custom, and Specific rules; it is not a replay of the last run and does not require
  Autopilot to be ON. It does not apply changes to the live calendar.
- Route > Find Jobs is the manual route-optimizer flow. It asks for a date range,
  defaults from the Auto-Pilot Optimization Window, previews Mantis output, and lets
  the user review/accept. Selection is per job; unselected jobs are excluded at accept.
- Each technician schedule has its own start/end address. Each optimized day's route is
  `schedule start address -> optimized jobs -> schedule end address`. Remove the old
  “Start from first job” concept for multi-technician routing.
- Agenda, Calendar, Map, and List share the date range filter. A range with no jobs
  shows an empty state; dates without jobs remain visible in the views. Map/preview is
  grouped per day and per technician.
- Downtime is only the waiting gap between jobs after travel. Do not include start/end
  location legs. Delay is actual technician start minus scheduled start; job duration
  does not change delay. Dashboard dates are kept even when no jobs exist.
- Freeze/horizon example: Today 13/08, Freeze 1 day, Horizon 7 days gives active
  optimization range 14/08–19/08. 13/08 is locked; 20/08 onward is not loaded.
- Restrict Job Movement OFF means no date restriction, except frozen dates. A job may
  move to any date in the routing range.
- Max Jobs/day is a soft target/cap behavior: try to respect it, but schedule all jobs
  when service time permits. If capacity forces spillover, use later-day spillover
  (Solution #3), even beyond Restrict. Do not leave the job at an overlapping original
  slot solely because the preferred capacity was reached.
- A job whose coordinates are too far away to route (another state/country) is flagged
  cannot-be-routed, kept in its current schedule, and uses IGNORE rather than
  route-around semantics.
- History details replace Sandbox Preview/Accept New Route with Undo. Undo is guarded
  because completed/cancelled/terminated jobs cannot be moved and the action cannot be
  undone. Routing defaults to “Move this Job and all Recurring”.
- System Routing Rules defaults: Auto-Pilot Run Frequency is always ON, default daily
  at 12:00 AM; Freeze Window is always ON, default until end of work day. The frozen
  window should be visible in Sandbox UI.

## Questions not answered in the issue thread

- Whether manual toolbar values merge additively with System rules, override them, or
  use a documented tighter-value rule. The repository verification contract currently
  says toolbar filters are additive and jobs/day/drive-buffer bind to the tighter value;
  label this as repository contract if the current checklist does not confirm it.
- Whether Arrival Window Duration Override is relative to the routed job or the original
  job. The current rule catalog classifies it as display behavior; verify against the
  current checklist/API semantics.
- Whether Customer Scheduling Preferences is Soft or Hard. The current catalog says
  Soft; if a newer checklist differs, report the conflict explicitly.
- Whether Service Type is mandatory when configuring Technician Skills.
- Relative order of unresolved soft preferences and several force-tech/region/skill/day
  exclusion conflicts. Use `priority-hierarchy.md`; otherwise probe feeds and label the
  result OBSERVED.

## Scope warning

DES-9619 is primarily a FE product story with eight FE subtasks. The backend/routing
semantics are confirmed through its comments and linked rule sheets, but UI acceptance
text does not by itself prove API behavior.
